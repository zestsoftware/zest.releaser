import z3c.testsetup


test_suite = z3c.testsetup.register_all_tests('tha.example')
